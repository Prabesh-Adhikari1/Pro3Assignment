import dk.via.pro3.slaughterhouse.database.SlaughterHouseRepository;

import java.util.ArrayList;

public class RepositoryTest
{
  static void main()
  {
    try{
      SlaughterHouseRepository slaughterHouseRepository= new SlaughterHouseRepository();

      ArrayList<String> animals= slaughterHouseRepository.findAnimalsForProduct(1);

      System.out.println("Animals used for product 1");
      for(String a: animals){
        System.out.println(a);
      }

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
