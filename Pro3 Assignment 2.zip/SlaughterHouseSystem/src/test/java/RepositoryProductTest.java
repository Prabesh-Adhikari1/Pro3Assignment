
import dk.via.pro3.slaughterhouse.Product;
import dk.via.pro3.slaughterhouse.database.SlaughterHouseRepository;

import java.util.ArrayList;

public class RepositoryProductTest {

  public static void main(String[] args) {

    try {
      SlaughterHouseRepository repository =
          new SlaughterHouseRepository();

      ArrayList<Product> products =
          repository.findProductsForAnimal("A001");

      System.out.println("Products used by animal A001:");

      for (Product product : products) {
        System.out.println(
            product.getProductId()
                + " - "
                + product.getProductType()
        );
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}