package dk.via.pro3.slaughterhouse.server;
import dk.via.pro3.slaughterhouse.*;
import dk.via.pro3.slaughterhouse.database.SlaughterHouseRepository;
import io.grpc.stub.StreamObserver;
import dk.via.pro3.slaughterhouse.AnimalRequest;
import java.util.ArrayList;

public class SlaughterHouseServiceImpl extends
    SlaughterHouseServiceGrpc.SlaughterHouseServiceImplBase
{
  private final SlaughterHouseRepository repository;

  public SlaughterHouseServiceImpl(){
    repository= new SlaughterHouseRepository();
  }

  @Override public void getAnimalsForProduct(ProductRequest request,
      StreamObserver<AnimalRegistrationsResponse> responseObserver)
  {
    try{
      ArrayList<String> registrationNumbers= repository.
          findAnimalsForProduct(request.getProductId());
      AnimalRegistrationsResponse response= AnimalRegistrationsResponse
          .newBuilder().
              addAllRegistrationNumbers(registrationNumbers)
          .build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();;

    }
    catch (Exception e)
    {
      responseObserver.onError(e);
    }
  }

  @Override public void getProductsForAnimal(AnimalRequest request,
      StreamObserver<ProductsResponse> responseObserver)
  {
    try {

      ArrayList<Product> products =
          repository.findProductsForAnimal(
              request.getAnimalRegistration());

      ProductsResponse response =
          ProductsResponse.newBuilder()
              .addAllProducts(products)
              .build();

      responseObserver.onNext(response);
      responseObserver.onCompleted();

    } catch (Exception e) {

      responseObserver.onError(e);
    }
  }
}
