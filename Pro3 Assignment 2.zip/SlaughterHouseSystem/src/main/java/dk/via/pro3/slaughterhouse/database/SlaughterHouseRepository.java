package dk.via.pro3.slaughterhouse.database;


import dk.via.pro3.slaughterhouse.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class SlaughterHouseRepository
{
  public ArrayList<String> findAnimalsForProduct(int productId)
    throws Exception{
    //noinspection SqlResolve
    String sql= """
        SELECT DISTINCT a.registration_number 
        from pro3.product as p
        join
        pro3.product_tray as  pt on
        p.product_id=pt.product_id
            
        join pro3.tray as t 
            on pt.tray_id=t.tray_id
            join pro3.animal_part as ap on
            ap.tray_id=t.tray_id
        join pro3.animal as a  
            on a.registration_number
        =ap.animal_registration_number
        where p.product_id= ?        
        """;
     ArrayList<String> registrationNumbers= new ArrayList<>();

     try(Connection connection= DatabaseConnection.getConnection();
     PreparedStatement statement= connection.prepareStatement(sql)){
       statement.setInt(1,productId);
       try(ResultSet resultSet= statement.executeQuery()){
          while(resultSet.next()){
            registrationNumbers.add(resultSet.getString("registration_number"));
          }
       }

     }

     return registrationNumbers;

  }
  public ArrayList<Product> findProductsForAnimal(String animalRegistrationNumber)
      throws Exception {
    //noinspection SqlResolve
    String sql = """
            SELECT DISTINCT p.product_id, p.product_type
            FROM pro3.animal AS a
            JOIN pro3.animal_part AS ap
                ON ap.animal_registration_number = a.registration_number
            JOIN pro3.tray AS t
                ON ap.tray_id = t.tray_id
            JOIN pro3.product_tray AS pt
                ON pt.tray_id = t.tray_id
            JOIN pro3.product AS p
                ON p.product_id = pt.product_id
            WHERE a.registration_number = ?
            """;

    ArrayList<Product> products = new ArrayList<>();

    try (Connection connection = DatabaseConnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql)) {

      statement.setString(1, animalRegistrationNumber);

      try (ResultSet resultSet = statement.executeQuery()) {

        while (resultSet.next()) {

          int productId =
              resultSet.getInt("product_id");

          String productType =
              resultSet.getString("product_type");

          products.add(
              Product.newBuilder().
                  setProductId(productId).
                  setProductType(productType).
                  build()
          );
        }
      }
    }

    return products;
  }
}
