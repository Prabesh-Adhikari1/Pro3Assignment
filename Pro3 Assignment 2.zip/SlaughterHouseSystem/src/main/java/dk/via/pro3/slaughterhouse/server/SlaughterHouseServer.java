package dk.via.pro3.slaughterhouse.server;

import io.grpc.Server;
import io.grpc.ServerBuilder;

public class SlaughterHouseServer
{
  static void main(String[] args) throws Exception
  {
    Server server= ServerBuilder. forPort(9090)
        .addService(new SlaughterHouseServiceImpl()).
        build().start();

    System.out.println("Slaughter house server is running on port 9090");
    server.awaitTermination();



  }
}
