package dk.via.pro3.slaughterhouse.database;

import java.sql.Connection;

public class DatabaseTest
{
   public static void main(String[] args)
  {
    try(Connection connection= DatabaseConnection.getConnection()){
      System.out.println("Database connection successfully");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
